# -*- coding: utf-8 -*-

from . import check_in_dict
