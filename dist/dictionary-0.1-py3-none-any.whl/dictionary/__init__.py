# -*- coding: utf-8 -*-

from . import dictionary

check_in_dict = dictionary.check_in_dict
